<?php return array (
  'admin.material-category.index' => 'App\\Http\\Livewire\\Admin\\MaterialCategory\\Index',
  'admin.material.index' => 'App\\Http\\Livewire\\Admin\\Material\\Index',
  'admin.measure.index' => 'App\\Http\\Livewire\\Admin\\Measure\\Index',
  'admin.project.details' => 'App\\Http\\Livewire\\Admin\\Project\\Details',
  'admin.project.index' => 'App\\Http\\Livewire\\Admin\\Project\\Index',
  'admin.user-role.index' => 'App\\Http\\Livewire\\Admin\\UserRole\\Index',
  'admin.user.active' => 'App\\Http\\Livewire\\Admin\\User\\Active',
  'admin.user.inactive' => 'App\\Http\\Livewire\\Admin\\User\\Inactive',
  'admin.user.index' => 'App\\Http\\Livewire\\Admin\\User\\Index',
  'admin.vendor.index' => 'App\\Http\\Livewire\\Admin\\Vendor\\Index',
);