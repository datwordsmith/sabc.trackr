require('./bootstrap');
import '@fortawesome/fontawesome-free/js/all';
