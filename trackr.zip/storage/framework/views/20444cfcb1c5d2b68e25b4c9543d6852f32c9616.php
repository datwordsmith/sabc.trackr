<div>
    <?php echo $__env->make('livewire.admin.project.details-modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <?php $__env->startSection('pagename'); ?>
        <i class="fas fa-project-diagram"></i> <?php echo e($project->name); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('breadcrumbs'); ?>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('t/projects')); ?>">All Projects</a></li>
            <li class="breadcrumb-item active" aria-current="page"> <?php echo e($project->name); ?></li>
        </ol>
    <?php $__env->stopSection(); ?>

    <div>
        <p>Welcome, <?php echo e($admin->name); ?> </p>
    </div>

    <!-- PROJECT INFO -->
    <div class="row">
        <!-- ROW 1, COL 1 -->
        <div class="col-md-4 d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-header text-light bg-success">
                    <div>
                        Project Info
                    </div>
                    <div class="ms-auto">

                    </div>
                </div>
                <div class="card-body p-4">
                    <div class="mb-3">
                        <h6 class="fw-semibold mb-1">Project Title</h6>
                        <span class="fw-normal"><?php echo e($project->name); ?></span>
                    </div>
                    <div class="mb-3">
                        <h6 class="fw-semibold mb-1">Description</h6>
                        <span class="fw-normal"><?php echo e($project->description); ?></span>
                    </div>
                    <div class="mb-3">
                        <h6 class="fw-semibold mb-1">Client</h6>
                        <?php if(!$editClient): ?>
                            <span class="fw-normal"><?php echo e($project->client); ?></span>
                            <?php if($superAdmin): ?>
                                <button class="btn btn-sm btn-warning ms-2" wire:click="toggleClient"><i
                                    class="fas fa-pencil-alt"></i></button>
                            <?php endif; ?>
                        <?php else: ?>
                            <input type="text" class="form-control form-control-sm d-inline-block w-auto"
                                wire:model.defer="client" wire:keydown.enter.prevent="updateClient"
                                wire:keydown.escape="toggleClient">
                            <button class="btn btn-sm btn-primary ms-2" wire:click="updateClient"><i
                                    class="fas fa-save"></i></button>
                            <button class="btn btn-sm btn-danger" wire:click="toggleClient"><i
                                    class="fas fa-times"></i></button>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 d-flex">
                        <div>
                            <h6 class="fw-semibold mb-1">Start</h6>
                            <span class="fw-normal"><?php echo e(date('d M, Y', strtotime($project->start_date))); ?></span>
                        </div>
                        <div class="ms-auto">
                            <h6 class="fw-semibold mb-1">Expected Delivery</h6>
                            <span
                                class="fw-normal"><?php echo e(date('d M, Y', strtotime($project->expected_delivery_date))); ?></span>
                        </div>
                        <div class="mb-3">

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- ROW 1, COL 2 -->
        <div class="col-md-8 d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body p-4">
                    <div class="border-bottom border-warning mb-3 d-flex">
                        <div>
                            <h5 class="card-title fw-semibold pb-2">Project Team</h5>
                        </div>
                        <div class="ms-auto">
                            <?php if($superAdmin): ?>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#assignTeamModal"
                                    class="btn btn-sm btn-primary text-white"><i class="fas fa-users-cog"></i> Project
                                    Team</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if(session('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <!-- LEFT COL -->
                        <?php $__currentLoopData = $projectUsers->sortBy('role.id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($projectUser->project_id == $project->id): ?>
                                <div class="col-6 pb-4">
                                    <strong><?php echo e($projectUser->role->role); ?></strong><br />
                                    <small><?php echo e($projectUser->user->name); ?></small>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php if($project && $project->status == 1): ?>
        <!-- BUDGET -->
        <div class="row">
            <div class="col-md-12">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-danger mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Project Budget</h5>
                            </div>
                            <div class="ms-auto">
                                <?php if($budgetItems->where('isApproved', 0)->count() > 0 && $budgetItems->where('quantity', '<', 1)->count() == 0 && $budgetItems->where('alert', '=', 0)->count() == 0): ?>
                                    <?php if(($budgetOfficer) || ($superAdmin)): ?>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#approveBudgetModal"
                                            class="btn btn-sm btn-success text-white me-2">
                                            <i class="fas fa-check-double"></i> Approve Budget
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($budgetItems->count() > 0): ?>
                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('primary_budget')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <!-- BUDGET, COL 1 -->
                            <div class="col-md-4 mb-3">
                                        <?php if(session()->has('supplementarybudget')): ?>
                                            <div class="alert <?php echo e(session('supplementarybudget')['class']); ?>">
                                                <?php echo e(session('supplementarybudget')['message']); ?>

                                            </div>
                                        <?php endif; ?>
                                        <?php if($project && $project->status == 1): ?>
                                                <?php if($budgetItems->count() > 0 && $budgetItems->where('isApproved', 0)->count() == 0): ?>
                                                    <div class="mt-3 text-center">
                                                        <p >
                                                            <i class="fas fa-check-circle fa-lg pr-3" style="color: #198754;"></i>
                                                            <h3>This budget is approved</h3>
                                                        </p>
                                                        <?php if($supplementaryBudgetStatus && $supplementaryBudgetStatus->status == 1): ?>
                                                            <p>
                                                                <div class="alert alert-success" >
                                                                    Supplementary Budget is Activated
                                                                </div>

                                                            </p>
                                                        <?php else: ?>
                                                            <a href="#" data-bs-toggle="modal" data-bs-target="#activateSupplementaryBudgetModal"
                                                                class="btn btn-sm btn-success text-white">
                                                                <i class="fas fa-plus"></i> Add Supplementary Budget
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="card w-100">
                                                        <div class="card-header text-light bg-warning">
                                                            Add Budget Items
                                                        </div>
                                                        <div class="card-body p-4">
                                                            <?php if(session('budgeterror')): ?>
                                                                <div class="alert alert-danger" role="alert">
                                                                    <?php echo e(session('budgeterror')); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                            <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                <form wire:submit.prevent="saveBudget()">
                                                                    <div class="mb-3">
                                                                        <select wire:model="selectedCategory" class="form-select" required>
                                                                            <option value="">Select a category</option>
                                                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <select wire:model="selectedMaterial" class="form-control"
                                                                            <?php if(empty($selectedCategory)): ?> disabled <?php endif; ?> required>
                                                                            <option value="">Select a material</option>
                                                                            <?php if(!empty($materials)): ?>
                                                                                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($material->category_id == $selectedCategory): ?>
                                                                                        <option value="<?php echo e($material->id); ?>"><?php echo e($material->name); ?></option>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                        </select>
                                                                    </div>

                                                                    <div class="d-grid">
                                                                        <button type="submit" class="btn btn-primary btn-lg">Save</button>
                                                                    </div>
                                                                </form>
                                                            <?php else: ?>
                                                                <div class="alert alert-warning">
                                                                    Please contact the Quantity Surveyor
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                        <?php else: ?>
                                            <strong class="text-center text-danger">Project is Inactive</strong>
                                        <?php endif; ?>
                            </div>

                            <!-- BUDGET, COL 2 -->
                            <div class="col-md-8">
                                <div>
                                        <?php if($project && $project->status == 1): ?>
                                            <div class="mb-3">
                                                <input type="text" class="form-control mb-2" wire:model="search" placeholder="Search...">
                                                <?php if(session('budgetapprovalerror')): ?>
                                                    <div class="alert alert-danger" role="alert">
                                                        Error
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(session('budgetapproved')): ?>
                                                    <div class="alert alert-success" role="alert">
                                                        Approved
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($alertQtyError)): ?>
                                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                        <?php echo e($alertQtyError); ?>

                                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="table-responsive">
                                                <table id="primary_budget" class="table table-striped align-items-center mb-0"
                                                    style="width:100%">
                                                    <thead class="table-dark">
                                                        <tr>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">
                                                                Material</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">
                                                                Category</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Unit
                                                            </th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">
                                                                Quantity</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">
                                                                    Alert Qty</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $budgetItems->sortBy('material.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budgetItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($budgetItem->material->name); ?></td>
                                                                <td><?php echo e($budgetItem->material->category->category); ?></td>
                                                                <td><?php echo e($budgetItem->material->unit->name); ?></td>
                                                                <td>
                                                                    <?php if($editQtyId !== $budgetItem->id): ?>
                                                                        <?php if((!$budgetItem->isApproved) && (($quantitySurveyor) || ($superAdmin))): ?>
                                                                            <button class="btn btn-sm btn-warning ms-2"
                                                                                wire:click="toggleQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                    class="fas fa-pencil-alt"></i></button>
                                                                        <?php endif; ?>
                                                                        <span class="fw-normal"><?php echo e($budgetItem->quantity); ?></span>
                                                                    <?php else: ?>
                                                                        <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                            <div class="input-group">
                                                                                <input type="number"
                                                                                    class="form-control form-control-sm d-inline-block w-auto-fit"
                                                                                    wire:model.defer="budgetqty"
                                                                                    wire:keydown.enter.prevent="updateQty(<?php echo e($budgetItem->id); ?>)"
                                                                                    wire:keydown.escape="toggleQty" min=0>
                                                                                <button class="btn btn-sm btn-primary ms-2"
                                                                                    wire:click="updateQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                        class="fas fa-save"></i></button>
                                                                                <button class="btn btn-sm btn-danger"
                                                                                    wire:click="toggleQty(null)"><i
                                                                                        class="fas fa-times"></i></button>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if($editAlertQtyId !== $budgetItem->id): ?>
                                                                        <?php if((!$budgetItem->isApproved) && (($quantitySurveyor)  || ($superAdmin))): ?>
                                                                            <button class="btn btn-sm btn-warning ms-2"
                                                                                wire:click="toggleAlertQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                    class="fas fa-pencil-alt"></i></button>
                                                                        <?php endif; ?>
                                                                        <span class="fw-normal"><?php echo e($budgetItem->alert); ?></span>
                                                                    <?php else: ?>
                                                                        <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                            <div class="input-group">
                                                                                <input type="number"
                                                                                    class="form-control form-control-sm d-inline-block w-auto-fit"
                                                                                    wire:model.defer="budgetalertqty"
                                                                                    wire:keydown.enter.prevent="updateAlertQty(<?php echo e($budgetItem->id); ?>)"
                                                                                    wire:keydown.escape="toggleAlertQty" min=0>
                                                                                <button class="btn btn-sm btn-primary ms-2"
                                                                                    wire:click="updateAlertQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                        class="fas fa-save"></i></button>
                                                                                <button class="btn btn-sm btn-danger"
                                                                                    wire:click="toggleAlertQty(null)"><i
                                                                                        class="fas fa-times"></i></button>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <!-- Action buttons for the budget item -->
                                                                    <div class="btn-group" role="group" aria-label="">
                                                                        <?php if($budgetItem->isApproved): ?>
                                                                                
                                                                        <?php else: ?>
                                                                            <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                                <a href="#"
                                                                                    wire:click="deleteBudget(<?php echo e($budgetItem->id); ?>)"
                                                                                    data-bs-toggle="modal" data-bs-target="#deleteBudgetModal"
                                                                                    class="btn btn-sm btn-danger text-white"><i
                                                                                        class="fas fa-trash-alt"></i></a>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <div class="row mt-2">
                                                    <?php echo e($budgetItems->links()); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- END BUDGET -->

        <!-- SUPPLEMENTARY BUDGET -->
        <?php if($supplementaryBudgetStatus && $supplementaryBudgetStatus->status == 1): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-danger mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Supplementary Budget</h5>
                            </div>
                            <div class="ms-auto">
                                <?php if($extraBudgetItems->where('isApproved', 0)->count() > 0 && $extraBudgetItems->where('quantity', '<', 1)->count() == 0 && $extraBudgetItems->where('alert', '=', 0)->count() == 0): ?>
                                    <?php if(($budgetOfficer) || ($superAdmin)): ?>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#approveExtraBudgetModal"
                                            class="btn btn-sm btn-success text-white me-2">
                                            <i class="fas fa-check-double"></i> Approve Budget
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($extraBudgetItems->count() > 0): ?>
                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('supplementary_budget')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row" id="extraBudget">
                            <!-- ROW 2, COL 1 -->
                            <div class="col-md-4 mb-3">
                                <?php if($project && $project->status == 1): ?>
                                        <?php if($extraBudgetItems->count() > 0 && $extraBudgetItems->where('isApproved', 0)->count() == 0): ?>
                                            <div class="mt-3 text-center">
                                                <p>
                                                    <i class="fas fa-check-circle fa-lg pr-3" style="color: #198754;"></i>
                                                    <h3>This budget is approved</h3>
                                                </p>
                                            </div>
                                        <?php else: ?>
                                            <div class="card w-100">
                                                <div class="card-header text-light bg-warning">
                                                    Add Budget Items
                                                </div>
                                                <div class="card-body p-4">
                                                    <?php if(session('extrabudgeterror')): ?>
                                                        <div class="alert alert-danger" role="alert">
                                                            <?php echo e(session('extrabudgeterror')); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                        <form wire:submit.prevent="saveExtraBudget()">
                                                            <div class="mb-3">
                                                                <select wire:model="selectedCategory" class="form-select" required>
                                                                    <option value="">Select a category</option>
                                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3">
                                                                <select wire:model="selectedMaterial" class="form-control"
                                                                    <?php if(empty($selectedCategory)): ?> disabled <?php endif; ?> required>
                                                                    <option value="">Select a material</option>
                                                                    <?php if(!empty($materials)): ?>
                                                                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($material->category_id == $selectedCategory): ?>
                                                                                <option value="<?php echo e($material->id); ?>"><?php echo e($material->name); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>

                                                            <div class="d-grid">
                                                                <button type="submit" class="btn btn-primary btn-lg">Save</button>
                                                            </div>
                                                        </form>
                                                    <?php else: ?>
                                                        <div class="alert alert-warning">
                                                            Please contact the Quantity Surveyor
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                <?php else: ?>
                                    <strong class="text-center text-danger">Project is Inactive</strong>
                                <?php endif; ?>
                            </div>

                            <!-- ROW 2, COL 2 -->
                            <div class="col-md-8">
                                <div>
                                        <?php if($project && $project->status == 1): ?>
                                            <div class="mb-3">
                                                <input type="text" class="form-control mb-2" wire:model="search" placeholder="Search...">
                                                <?php if(session('budgetapprovalerror')): ?>
                                                    <div class="alert alert-danger" role="alert">
                                                        Error
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(session('budgetapproved')): ?>
                                                    <div class="alert alert-success" role="alert">
                                                        Approved
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($extraAlertQtyError)): ?>
                                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                        <?php echo e($extraAlertQtyError); ?>

                                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="table-responsive">
                                                <table id="supplementary_budget" class="table table-striped align-items-center mb-0"
                                                    style="width:100%">
                                                    <thead class="table-dark">
                                                        <tr>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">
                                                                Material</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">
                                                                Category</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Unit
                                                            </th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">
                                                                Quantity</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">
                                                                    Alert Qty</th>
                                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $extraBudgetItems->sortBy('material.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budgetItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($budgetItem->material->name); ?></td>
                                                                <td><?php echo e($budgetItem->material->category->category); ?></td>
                                                                <td><?php echo e($budgetItem->material->unit->name); ?></td>
                                                                <td>
                                                                    <?php if($editQtyId !== $budgetItem->id): ?>
                                                                        <?php if((!$budgetItem->isApproved) && (($quantitySurveyor) || ($superAdmin))): ?>
                                                                            <button class="btn btn-sm btn-warning ms-2"
                                                                                wire:click="toggleQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                    class="fas fa-pencil-alt"></i></button>
                                                                        <?php endif; ?>
                                                                        <span class="fw-normal"><?php echo e($budgetItem->quantity); ?></span>
                                                                    <?php else: ?>
                                                                        <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                            <div class="input-group">
                                                                                <input type="number"
                                                                                    class="form-control form-control-sm d-inline-block w-auto-fit"
                                                                                    wire:model.defer="budgetqty"
                                                                                    wire:keydown.enter.prevent="updateQty(<?php echo e($budgetItem->id); ?>)"
                                                                                    wire:keydown.escape="toggleQty" min=0>
                                                                                <button class="btn btn-sm btn-primary ms-2"
                                                                                    wire:click="updateQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                        class="fas fa-save"></i></button>
                                                                                <button class="btn btn-sm btn-danger"
                                                                                    wire:click="toggleQty(null)"><i
                                                                                        class="fas fa-times"></i></button>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if($editAlertQtyId !== $budgetItem->id): ?>
                                                                        <?php if((!$budgetItem->isApproved) && (($quantitySurveyor) || ($superAdmin))): ?>
                                                                            <button class="btn btn-sm btn-warning ms-2"
                                                                                wire:click="toggleAlertQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                    class="fas fa-pencil-alt"></i></button>
                                                                        <?php endif; ?>
                                                                        <span class="fw-normal"><?php echo e($budgetItem->alert); ?></span>
                                                                    <?php else: ?>
                                                                        <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                            <div class="input-group">
                                                                                <input type="number"
                                                                                    class="form-control form-control-sm d-inline-block w-auto-fit"
                                                                                    wire:model.defer="budgetalertqty"
                                                                                    wire:keydown.enter.prevent="updateAlertQty(<?php echo e($budgetItem->id); ?>)"
                                                                                    wire:keydown.escape="toggleAlertQty" min=0>
                                                                                <button class="btn btn-sm btn-primary ms-2"
                                                                                    wire:click="updateAlertQty(<?php echo e($budgetItem->id); ?>)"><i
                                                                                        class="fas fa-save"></i></button>
                                                                                <button class="btn btn-sm btn-danger"
                                                                                    wire:click="toggleAlertQty(null)"><i
                                                                                        class="fas fa-times"></i></button>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <!-- Action buttons for the budget item -->
                                                                    <div class="btn-group" role="group" aria-label="">
                                                                        <?php if($budgetItem->isApproved): ?>
                                                                            
                                                                        <?php else: ?>
                                                                            <?php if(($quantitySurveyor) || ($superAdmin)): ?>
                                                                                <a href="#"
                                                                                wire:click="deleteBudget(<?php echo e($budgetItem->id); ?>)"
                                                                                data-bs-toggle="modal" data-bs-target="#deleteBudgetModal"
                                                                                class="btn btn-sm btn-danger text-white"><i
                                                                                    class="fas fa-trash-alt"></i></a>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <div class="row mt-2">
                                                    <?php echo e($extraBudgetItems->links()); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!-- END SUPPLEMENTARY BUDGET -->

        <!-- CUMMULATIVE BUDGET -->
        <div class="row">
            <div class="col-md-12">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-danger mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Cummulative Project Budget</h5>
                            </div>
                            <div class="ms-auto">
                                <?php if($allBudgetItems->count() > 0): ?>
                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('cummulative_budget')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div>
                                        <?php if($project && $project->status == 1): ?>
                                            <div class="mb-3">
                                                <input type="text" class="form-control mb-2" wire:model="search" placeholder="Search...">
                                            </div>
                                            <?php if(session('alertmessage')): ?>
                                                <div class="mb-3 alert alert-danger alert-dismissible fade show" role="alert">
                                                    <i class="fas fa-exclamation-triangle pe-1" style="color: #ff0000;"></i> <?php echo e(session('alertmessage')); ?>

                                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                </div>
                                            <?php endif; ?>

                                            <div class="table-responsive">
                                                <table id="cummulative_budget" class="table table-striped align-items-center mb-0"
                                                    style="width:100%">
                                                    <thead class="table-dark">
                                                        <tr class="text-secondary text-xs font-weight-semibold opacity-7">
                                                            <th class=" col-2">
                                                                Material</th>
                                                            <th class="col-2">
                                                                Category</th>
                                                            <th class="col-1">Unit
                                                            </th>
                                                            <th class="col-2 text-center">
                                                                Budget Qty</th>
                                                            <th class="col-2 text-center">
                                                                    Requisitions</th>
                                                            <th class="col-2 text-center">
                                                                    Budget Balance</th>
                                                            <th class="col-2 text-center">
                                                                    Alert</th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $allBudgetItems->sortBy('material.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budgetItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $isSendAlert = $budgetItem->budgetBalance <= $budgetItem->alert;

                                                            ?>
                                                            <tr class="<?php echo e($isSendAlert ? 'table-danger' : ''); ?>">
                                                                <td><?php echo e($budgetItem->material->name); ?></td>
                                                                <td><?php echo e($budgetItem->material->category->category); ?></td>
                                                                <td><?php echo e($budgetItem->material->unit->name); ?></td>
                                                                <td class="text-center"><?php echo e($budgetItem->quantity); ?></td>
                                                                <td class="text-center"><?php echo e($budgetItem->requisitionSum); ?></td>
                                                                <td class="text-center">
                                                                    <?php if($isSendAlert): ?>
                                                                        <i class="fas fa-exclamation-triangle pe-1" style="color: #ff0000;"></i>
                                                                    <?php endif; ?>
                                                                    <?php echo e($budgetItem->budgetBalance); ?>

                                                                </td>
                                                                <td class="text-center"><?php echo e($budgetItem->alert); ?></td>
                                                                <td>
                                                                    <?php if(($budgetItem->quantity == 0) && ($budgetItem->budgetBalance == 0)): ?>
                                                                        <span class="badge bg-warning">Pending</span>
                                                                    <?php elseif(($budgetItem->quantity > 0) && ($budgetItem->budgetBalance == 0)): ?>
                                                                        <span class="badge bg-warning">Pending</span>
                                                                    <?php else: ?>
                                                                        <?php if(($projectManager) || ($superAdmin)): ?>
                                                                            <a href="#"
                                                                                wire:click="makeRequisition(<?php echo e($budgetItem->id); ?>)"
                                                                                data-bs-toggle="modal" data-bs-target="#requisitionModal"
                                                                                class="btn btn-sm btn-success text-white"> Request</a>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                <div class="row mt-2">
                                                    <?php echo e($allBudgetItems->links()); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- END ALL BUDGETS -->

        <!-- REQUISITION -->
        <div class="row">
            <!-- ROW 3, COL 1 -->
            <div class="col-md-12 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-warning mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Project Requisitions</h5>
                            </div>
                            <div class="ms-auto">
                                <?php if($project && $project->status == 1 && $allRequisitions->count() > 0): ?>
                                    <?php if(($procurementOfficer) || ($superAdmin)): ?>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#approveRequisitionModal"
                                            class="btn btn-sm btn-success text-white"><i class="fas fa-check-double"></i>
                                            <span class="d-none d-md-inline">Approve All</span></a>
                                    <?php endif; ?>

                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('requisitions')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>

                        </div>
                        <?php if($project && $project->status == 1): ?>
                            <div class="mb-3">
                                <input type="text" class="form-control" wire:model="requisitionSearch"
                                    placeholder="Search...">
                            </div>
                            <div class="table-responsive">
                                <table id="requisitions" class="table table-striped align-items-center mb-0"
                                    style="width:100%">
                                    <thead class="table-dark">
                                        <tr class="text-secondary text-xs font-weight-semibold opacity-7">
                                            <th class="col-2">Date</th>
                                            <th class="col-2">Material</th>
                                            <th class="col-1">Category</th>
                                            <th class="col-2">Vendor</th>
                                            <th class="col-2">Activity</th>
                                            <th class="col-1">Quantity</th>
                                            <th class="col-1 text-center">Approval</th>
                                            <th class="col-1"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allRequisitions->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(Carbon\Carbon::parse($requisition->created_at)->format('d-M-Y')); ?>

                                                </td>
                                                <td><?php echo e($requisition->budget->material->name); ?> (<?php echo e($requisition->budget->material->unit->name); ?>)
                                                </td>
                                                <td><?php echo e($requisition->budget->material->category->category); ?></td>
                                                <td><?php echo e($requisition->vendor_name); ?></td>
                                                <td><?php echo e($requisition->activity); ?></td>
                                                <td><?php echo e($requisition->quantity); ?></td>
                                                <td class="text-center">
                                                    <?php if($requisition->status == '1'): ?>
                                                        <span class="badge bg-success">Approved</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning">Pending</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if(!$requisition->status == '1'): ?>
                                                        <div class="btn-group" role="group" aria-label="">
                                                            <?php if(($projectManager) || ($superAdmin)): ?>
                                                                <a href="#"
                                                                    wire:click="deleteRequisition(<?php echo e($requisition->id); ?>)"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#deleteRequisitionModal"
                                                                    class="btn btn-sm btn-danger text-white"><i
                                                                        class="fas fa-trash-alt"></i></a>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>



                                <div class="row mt-2">
                                    <?php echo e($allRequisitions->links()); ?>

                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- END REQUISITION -->

        <!-- INFLOW -->
        <div class="row">
            <!-- ROW 4, COL 1 -->
            <div class="col-md-12 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-danger mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Material Infow (Store)</h5>
                            </div>
                            <div class="ms-auto">
                                <div class="btn-group" role="group" aria-label="">
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#supplyModal"
                                            class="btn btn-sm btn-success text-white"><i
                                            class="far fa-arrow-alt-circle-right fa-rotate-90"></i> <span class="d-none d-md-inline">In</span></a>
                                </div>
                                <?php if($inventoryItems->count() > 0): ?>
                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('materialInflow')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <!-- ROW 2, COL 1 -->
                            <div class="col-md-12">
                                <div>

                                    <div class="mb-3">
                                        <input type="text" class="form-control mb-2" wire:model="inventorySearch" placeholder="Search...">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped align-items-center mb-0" id="materialInflow">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Material</th>
                                                    <th>Category</th>
                                                    <th>Quantity</th>
                                                    <th>Purpose</th>
                                                    <th class="text-center">Status</th>
                                                    <th>Received By</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $inventoryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($inventoryItem->created_at->format('d-M-Y')); ?></td>
                                                        <td><?php echo e($inventoryItem->material->name); ?> (<?php echo e($inventoryItem->material->unit->name); ?>)</td>
                                                        <td><?php echo e($inventoryItem->material->category->category); ?></td>
                                                        <td class="text-center"><?php echo e($inventoryItem->quantity); ?></td>
                                                        <td><?php echo e($inventoryItem->purpose); ?></td>
                                                        <td class="text-center">
                                                            <?php if($inventoryItem->flow == 1): ?>
                                                                <span class="badge bg-success">Inflow</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-danger">Out</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($inventoryItem->receiver); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php echo e($inventoryItems->links()); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- END INFLOW -->

        <!-- ALLOCATION -->
        <div class="row">
            <!-- ROW 4, COL 1 -->
            <div class="col-md-12 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-danger mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Material Allocation (From Store)</h5>
                            </div>
                            <div class="ms-auto">
                                <div class="btn-group" role="group" aria-label="">
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#distributionModal"
                                            class="btn btn-sm btn-danger text-white"><i
                                            class="far fa-arrow-alt-circle-right fa-rotate-270"></i> <span class="d-none d-md-inline">Out</span></a>
                                    <?php if(($allocatedItems->count() > 0) && (($materialManager) || ($superAdmin))): ?>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#approveAllocationModal"
                                            class="btn btn-sm btn-success text-white"><i class="fas fa-check-double"></i>
                                            <span class="d-none d-md-inline">Approve All</span></a>
                                    <?php endif; ?>
                                </div>
                                <?php if($allocatedItems->count() > 0): ?>
                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('materialDistribution')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <!-- ROW 2, COL 1 -->
                            <div class="col-md-12">
                                <div>

                                    <div class="mb-3">
                                        <input type="text" class="form-control mb-2" wire:model="allocationSearch" placeholder="Search...">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped align-items-center mb-0" id="materialDistribution">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Material</th>
                                                    <th>Category</th>
                                                    <th class="text-center">Quantity</th>
                                                    <th>Purpose</th>
                                                    <th class="text-center">Status</th>
                                                    <th>Receiver</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $allocatedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocatedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($allocatedItem->created_at->format('d-M-Y')); ?></td>
                                                        <td><?php echo e($allocatedItem->material->name); ?> (<?php echo e($allocatedItem->material->unit->name); ?>)</td>
                                                        <td><?php echo e($allocatedItem->material->category->category); ?></td>
                                                        <td class="text-center"><?php echo e($allocatedItem->quantity); ?></td>
                                                        <td><?php echo e($allocatedItem->purpose); ?></td>
                                                        <td class="text-center">
                                                            <?php if($allocatedItem->flow == '1'): ?>
                                                                <span class="badge bg-success">Approved</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-warning">Pending</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($allocatedItem->receiver); ?></td>
                                                        <td>
                                                            <?php if(($allocatedItem->flow == 0) && (($projectManager) || ($superAdmin))): ?>
                                                                <a href="#"
                                                                    wire:click="deleteAllocation(<?php echo e($allocatedItem->id); ?>)"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#deleteAllocationModal"
                                                                    class="btn btn-sm btn-danger text-white"><i
                                                                        class="fas fa-trash-alt"></i></a>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php echo e($allocatedItems->links()); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- END ALLOCATION -->

        <!-- STORE -->
        <div class="row">
            <!-- ROW 4, COL 1 -->
            <div class="col-md-12 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <div class="border-bottom border-danger mb-3 d-flex">
                            <div>
                                <h5 class="card-title fw-semibold pb-2">Project Inventory Report</h5>
                            </div>
                            <div class="ms-auto">
                                <?php if($storeItems->count() > 0): ?>
                                    <button type="button" class="btn btn-sm btn-info " onclick="exportToCSV('inventory')"><i class="fas fa-file-csv fa-lg"></i> <span class="d-none d-md-inline">Export</span></button>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <!-- ROW 2, COL 1 -->
                            <div class="col-md-12">
                                <div>

                                    <div class="mb-3">
                                        <input type="text" class="form-control mb-2" wire:model="storeSearch" placeholder="Search...">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped align-items-center mb-0" id="inventory">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>Material</th>
                                                    <th>Category</th>
                                                    <th>Budgeted</th>
                                                    <th>Inflow</th>
                                                    <th>Out</th>
                                                    <th>Stock Balance</th>
                                                    <th>Approved Requisition</th>
                                                    <th>Supply Balance</th>
                                                    <th>Budget Balance</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $storeItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storeItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($storeItem->material->name); ?> (<?php echo e($storeItem->material->unit->name); ?>)</td>
                                                        <td><?php echo e($storeItem->material->category->category); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->totalBudgetQuantity); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->inflowSum); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->outgoingSum); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->inflowSum - $storeItem->outgoingSum); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->requisitionSum); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->supplyBalance); ?></td>
                                                        <td class="text-center"><?php echo e($storeItem->budgetBalance); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php echo e($storeItems->links()); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- END STORE -->
    <?php else: ?>
        <div class="row">

            <div class="alert alert-danger text-center h6">
                <i class="fas fa-lock me-2"></i> This project is inactive, please contact the Administrator or the Project Manager.
            </div>

        </div>
    <?php endif; ?>
</div>


<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.3/xlsx.full.min.js"></script>

    <script>

        window.addEventListener('close-modal', event => {
            $('#assignTeamModal').modal('hide');
            $('#deleteBudgetModal').modal('hide');
            $('#requisitionModal').modal('hide');
            $('#approveBudgetModal').modal('hide');
            $('#approveExtraBudgetModal').modal('hide');
            $('#approveRequisitionModal').modal('hide');
            $('#deleteRequisitionModal').modal('hide');
            $('#activateSupplementaryBudgetModal').modal('hide');
            $('#supplyModal').modal('hide');
            $('#distributionModal').modal('hide');
            $('#deleteAllocationModal').modal('hide');
            $('#approveAllocationModal').modal('hide');
        });


        function exportToCSV(tableId) {
            const table = document.querySelector(`#${tableId}`);
            const csv = toCSV(table);
            downloadFile(csv, 'csv', `${tableId}_report.csv`);
        }

        function toCSV(table) {
            const t_rows = table.querySelectorAll('tr');
            return [...t_rows].map(row=>{
                const cells = row.querySelectorAll('th, td');
                return [...cells].map(cell => cell.textContent.trim()).join(',');
            }).join('\n')
        }

        function downloadFile(data, fileType, fileName = '') {
            const a = document.createElement('a');
            a.download = fileName;
            const mime_types = {
                'json':'application/json',
                'csv':'text/csv',
                'excel': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            }
            a.href = `
                data:${mime_types[fileType]};charset=utf-8,${encodeURIComponent(data)}
            `;
            document.body.appendChild(a);
            a.click();
            a.remove();
        }

        document.getElementById('openAlert').addEventListener('click', function () {
            Swal.fire({
                title: 'Alert Title',
                text: 'This is your SweetAlert message.',
                icon: 'success', // You can use 'success', 'error', 'warning', 'info', etc.
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/project/details.blade.php ENDPATH**/ ?>