<div>
    <?php echo $__env->make('livewire.admin.user.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('pagename'); ?>
        <i class="fas fa-users"></i> Users
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('breadcrumbs'); ?>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">All Users</li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('t/users/active')); ?>">Active</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('t/users/inactive')); ?>">Inactive</a></li>
        </ol>
    <?php $__env->stopSection(); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body p-4">
                    <div class="col-md-12 d-flex mb-2">
                        
                        <div class="ms-auto">
                            <?php if($admin->isAdmin): ?>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#addUserModal" class="btn btn-sm btn-primary text-white"><i class="fas fa-plus-square pr-4"></i>&nbsp;&nbsp; Add User</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(session('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <input type="text" class="form-control" wire:model="search" placeholder="Search...">
                    </div>
                    <div class="table-responsive">
                        <table id="category_table" class="table table-striped align-items-center mb-0" style="width:100%">
                            <thead class="table-dark">
                                <tr class="">
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-4">Name</th>
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-4">Email Address</th>
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1 text-center">Status</th>
                                    <?php if($admin->isAdmin): ?>
                                        <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td class="text-center">

                                            <?php if($user->status == '1'): ?>
                                                <i class="far fa-check-circle text-success"></i>
                                                
                                            <?php else: ?>
                                                <i class="fas fa-ban text-danger"></i>
                                            <?php endif; ?>
                                        </td>
                                        <?php if($admin->isAdmin): ?>
                                            <td class="">
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <a href="#" wire:click="editUser(<?php echo e($user->id); ?>)" data-bs-toggle="modal" data-bs-target="#editUserModal" class="btn btn-sm btn-warning text-white"><i class="fas fa-pen"></i></a>
                                                    <a href="#" wire:click="deleteUser(<?php echo e($user->id); ?>)" data-bs-toggle="modal" data-bs-target="#deleteUserModal" class="btn btn-sm btn-danger text-white"><i class="fas fa-trash-alt"></i></a>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-danger">No Project Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="row mt-2">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            window.addEventListener('close-modal', event => {
                $('#addUserModal').modal('hide');
                $('#editUserModal').modal('hide');
                $('#deleteUserModal').modal('hide');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/user/index.blade.php ENDPATH**/ ?>