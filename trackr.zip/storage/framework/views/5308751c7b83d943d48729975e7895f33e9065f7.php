<!-- ADD BUDGET MODAL -->
<div wire:ignore.self class="modal fade" id="setBudgetModal" tabindex="-1" aria-hidden="true" wire:dirty.class="dummy">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header border-bottom border-warning">
                <h1 class="modal-title fs-5">Assign Project Budget</h1>
                <button type="button" class="btn-close" wire:click="closeModalAndRefresh" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form wire:submit.prevent="saveBudget">
                <div class="modal-body">
                    <div class="row">
                        <div>
                            <h5>Unassigned Materials</h5>
                            <?php $__currentLoopData = $unassignedMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="checkbox" value="<?php echo e($material->id); ?>" wire:model="selectedMaterials.<?php echo e($material->id); ?>.isSelected">
                                    <label><?php echo e($material->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div>
                            <h5>Assigned Materials</h5>
                            <?php $__currentLoopData = $assignedMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <label><?php echo e($material->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" wire:click="closeModalAndRefresh">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- END ADD MODAL -->
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/project/budget-modal-form.blade.php ENDPATH**/ ?>