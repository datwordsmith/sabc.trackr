<div>
    <?php echo $__env->make('livewire.admin.user-role.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('pagename'); ?>
        <i class="fas fa-tasks"></i> User Roles
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('breadcrumbs'); ?>
        
    <?php $__env->stopSection(); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body p-4">
                    <div class="col-md-12 d-flex mb-2">
                        <div>
                            
                        </div>
                        <div class="ms-auto">
                            <?php if($admin->isAdmin): ?>
                                <!--<a href="#" data-bs-toggle="modal" data-bs-target="#addRoleModal" class="btn btn-sm btn-primary text-white"><i class="fas fa-plus-square pr-4"></i>&nbsp;&nbsp; Add User Role</a>-->
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(session('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table id="category_table" class="table table-striped align-items-center mb-0" style="width:100%">
                            <thead class="table-dark">
                                <tr class="">
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-10">User Role</th>
                                    <?php if($admin->isAdmin): ?>
                                        <!--
                                            <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Action</th>
                                        -->
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $user_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($user_role->role); ?></td>
                                    <?php if($admin->isAdmin): ?>
                                        <!--
                                        <td class="">
                                            <div class="btn-group" role="group" aria-label="">
                                                <a href="#" wire:click="editRole(<?php echo e($user_role->id); ?>)" data-bs-toggle="modal" data-bs-target="#editRoleModal" class="btn btn-sm btn-warning text-white"><i class="far fa-edit"></i></a>
                                                <a href="#" wire:click="deleteRole(<?php echo e($user_role->id); ?>)" data-bs-toggle="modal" data-bs-target="#deleteRoleModal" class="btn btn-sm btn-danger text-white"><i class="fas fa-trash-alt"></i></a>
                                            </div>
                                        </td>
                                        -->
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-danger">No User Role Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="row mt-2">
                            <?php echo e($user_roles->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        window.addEventListener('close-modal', event => {
            $('#addRoleModal').modal('hide');
            $('#editRoleModal').modal('hide');
            $('#deleteRoleModal').modal('hide');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/user-role/index.blade.php ENDPATH**/ ?>