<?php
function export_to_excel($table) {
    $html = '<table>';
    foreach ($table as $row) {
        $html .= '<tr>';
        foreach ($row as $cell) {
            $html .= '<td>' . $cell . '</td>';
        }
        $html .= '</tr>';
    }
    $html .= '</table>';

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename=export.xls');
    echo $html;
}
?>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/project/export-to-excel.blade.php ENDPATH**/ ?>