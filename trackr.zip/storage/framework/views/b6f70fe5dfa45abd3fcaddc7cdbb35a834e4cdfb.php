<div>
    <?php echo $__env->make('livewire.admin.material-category.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('pagename'); ?>
        <i class="fas fa-puzzle-piece"></i> Material Categories
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('breadcrumbs'); ?>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Material Categories</li>
            </ol>
    <?php $__env->stopSection(); ?>

    <div class="row">
        <div class="col-md-4">
            <div class="card w-100">
                <div class="card-header text-light bg-dark">
                    Add New
                  </div>
                <div class="card-body p-4">
                    <?php if($admin->isAdmin): ?>
                        <form wire:submit.prevent="storeCategory()">
                            <div class="mb-3">

                                <input type="text" class="form-control" placeholder = "Material Category" wire:model.defer="category">
                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="error text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">Save</button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-circle me-2"></i> You are not allowed to add New items. Please contact Administrator.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- CATEGORY LISTING -->
        <div class="col-md-8 d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body p-4">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <input type="text" class="form-control" wire:model="search" placeholder="Search...">
                    </div>
                    <div class="table-responsive">
                        <table id="category_table" class="table table-striped align-items-center mb-0" style="width:100%">
                            <thead class="table-dark">
                                <tr class="">
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-10">Category</th>
                                    <?php if($admin->isAdmin): ?>
                                        <th class="text-secondary text-xs font-weight-semibold opacity-7 col-2">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($category->category); ?></td>
                                        <?php if($admin->isAdmin): ?>
                                            <td class="">
                                                <div class="btn-group" role="group" aria-label="">
                                                    <a href="#" wire:click="editCategory(<?php echo e($category->id); ?>)" data-bs-toggle="modal" data-bs-target="#editCategoryModal" class="btn btn-sm btn-warning text-white"><i class="fas fa-pen"></i></a>
                                                    <a href="#" wire:click="deleteCategory(<?php echo e($category->id); ?>)" data-bs-toggle="modal" data-bs-target="#deleteCategoryModal" class="btn btn-sm btn-danger text-white"><i class="fas fa-trash-alt"></i></a>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-danger">No Material Category Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="row mt-2">
                            <?php echo e($categories->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            window.addEventListener('close-modal', event => {
                $('#addCategoryModal').modal('hide');
                $('#editCategoryModal').modal('hide');
                $('#deleteCategoryModal').modal('hide');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/material-category/index.blade.php ENDPATH**/ ?>