<div>
    <?php echo $__env->make('livewire.admin.vendor.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('pagename'); ?>
        <i class="fas fa-project-diagram"></i> Vendors
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('breadcrumbs'); ?>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Vendors</li>
        </ol>
    <?php $__env->stopSection(); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body p-4">
                    <div class="col-md-12 d-flex mb-2">
                        <div>
                            <h5 class="card-title fw-semibold mb-4">Vendor Listing</h5>
                        </div>
                        <div class="ms-auto">
                            <?php if($admin->isAdmin): ?>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#addVendorModal" class="btn btn-sm btn-primary text-white"><i class="fas fa-plus-square pr-4"></i>&nbsp;&nbsp; Add vendor</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(session('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <input type="text" class="form-control" wire:model="search" placeholder="Search...">
                    </div>
                    <div class="table-responsive">
                        <table id="category_table" class="table table-striped align-items-center mb-0" style="width:100%">
                            <thead class="table-dark">
                                <tr class="">
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-3">Name</th>
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Phone</th>
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-2">Email</th>
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Location</th>
                                    <th class="text-secondary text-xs font-weight-semibold opacity-7 col-2">Services</th>
                                    <?php if($admin->isAdmin): ?>
                                        <th class="text-secondary text-xs font-weight-semibold opacity-7 col-1">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($vendor->name); ?></td>
                                    <td><?php echo e($vendor->phone); ?></td>
                                    <td><?php echo e($vendor->email); ?></td>
                                    <td><?php echo e($vendor->location); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $vendor->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($service->service); ?>

                                            <?php if(!$loop->last): ?>
                                                ,
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <?php if($admin->isAdmin): ?>
                                        <td class="">
                                            <div class="btn-group" role="group">
                                                <a href="#" wire:click="editVendor(<?php echo e($vendor->id); ?>)" data-bs-toggle="modal" data-bs-target="#editVendorModal" class="btn btn-sm btn-warning text-white"><i class="far fa-edit"></i></a>
                                                <a href="#" wire:click="deleteVendor(<?php echo e($vendor->id); ?>)" data-bs-toggle="modal" data-bs-target="#deleteVendorModal" class="btn btn-sm btn-danger text-white"><i class="fas fa-trash-alt"></i></a>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-danger">No Vendor Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="row mt-2">
                            <?php echo e($vendors->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        window.addEventListener('close-modal', event => {
            $('#addVendorModal').modal('hide');
            $('#editVendorModal').modal('hide');
            $('#deleteVendorModal').modal('hide');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/livewire/admin/vendor/index.blade.php ENDPATH**/ ?>