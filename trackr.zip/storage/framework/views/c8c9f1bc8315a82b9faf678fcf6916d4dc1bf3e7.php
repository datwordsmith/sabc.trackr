<aside class="left-sidebar bg-danger-subtle">
    <!-- Sidebar scroll-->
    <div>
      <div class="brand-logo d-flex align-items-center justify-content-between">
        <a href="<?php echo e(url('t/projects')); ?>" class="text-nowrap logo-img">
          <img src="<?php echo e(asset('assets/trackr_logo_main.png')); ?>" width="180" alt="" />
        </a>
        <div class="close-btn d-xl-none d-block sidebartoggler " id="sidebarCollapse">
            <i class="fas fa-bars" style="color: #ffffff;"></i>
        </div>
      </div>
      <!-- Sidebar navigation-->
      <nav class="sidebar-nav scroll-sidebar mt-5 pb-5" data-simplebar="">
        <ul id="sidebarnav">
          
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/projects')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-project-diagram"></i>
              </span>
              <span class="hide-menu">Projects</span>
            </a>
          </li>
          
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/user_roles')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-tasks"></i>
              </span>
              <span class="hide-menu">User Roles</span>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/users')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-users"></i>
              </span>
              <span class="hide-menu">Users</span>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/material-categories')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-puzzle-piece"></i>
              </span>
              <span class="hide-menu">Categories</span>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/measures')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-ruler-combined"></i>
              </span>
              <span class="hide-menu">Units/Measures</span>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/materials')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-tools"></i>
              </span>
              <span class="hide-menu">Site Materials</span>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(url('t/vendors')); ?>" aria-expanded="false">
              <span>
                <i class="fas fa-user-tag"></i>
              </span>
              <span class="hide-menu">Vendors</span>
            </a>
          </li>
          

          
        <div class="hide-menu position-relative mb-7 mt-5 rounded">
          <div class="d-flex">

            <div class="">
              
              <img src="<?php echo e(asset('assets/sabc_logo.png')); ?>" alt="" class="img-fluid">
            </div>
          </div>
        </div>
      </nav>
      <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
  </aside>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/layouts/inc/_sidebar.blade.php ENDPATH**/ ?>