<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/trackr_favicon.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/styles.min.css')); ?>" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.min.css">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="page-wrapper bg-body-white" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">

        <?php echo $__env->make('layouts.inc._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="body-wrapper">
            <?php echo $__env->make('layouts.inc._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="container-fluid">
                <!-- Title -->
                <div class="row py-2">
                    <div class="d-flex">
                        <div class="flex-grow-1">
                            <h3 class="page-title"> <?php echo $__env->yieldContent('pagename'); ?> </h3>
                            <nav class="d-md-none">
                                <?php echo $__env->yieldContent('breadcrumbs'); ?>
                            </nav>
                        </div>
                        <div class="ms-0 d-none d-md-block">
                            <nav>
                                <?php echo $__env->yieldContent('breadcrumbs'); ?>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- End Title -->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('admin/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/sidebarmenu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/simplebar/dist/simplebar.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.min.js"></script>



    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\Users\emeka\laravel\tracka\resources\views/layouts/admin.blade.php ENDPATH**/ ?>